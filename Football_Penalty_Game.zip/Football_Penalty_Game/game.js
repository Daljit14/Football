// Game variables
let canvas, ctx;
let gameState = 'menu';
let goals = 0;
let saves = 0;

// Game objects
const goalkeeper = {
    x: 400,
    y: 450,
    width: 80,
    height: 80,
    speed: 5,
    diving: false,
    diveDirection: null,
    diveProgress: 0,
    draw() {
        ctx.fillStyle = '#ff0000';
        if (this.diving) {
            // Animate diving motion
            this.diveProgress += 0.1;
            if (this.diveDirection === 'left') {
                this.x = Math.max(this.x - this.speed * 2, 200);
            } else {
                this.x = Math.min(this.x + this.speed * 2, 600);
            }
            if (this.diveProgress >= 1) {
                this.resetDive();
            }
        }
        ctx.fillRect(this.x - this.width / 2, this.y - this.height / 2, this.width, this.height);
    },
    dive(direction) {
        if (!this.diving) {
            this.diving = true;
            this.diveDirection = direction;
            this.diveProgress = 0;
        }
    },
    resetDive() {
        this.diving = false;
        this.diveDirection = null;
        this.diveProgress = 0;
        this.x = 400;
    }
};

const ball = {
    x: 400,
    y: 500,
    radius: 10,
    speed: 8,
    active: false,
    direction: { x: 0, y: 0 },
    draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        ctx.closePath();
    },
    update() {
        if (this.active) {
            this.x += this.direction.x * this.speed;
            this.y += this.direction.y * this.speed;
            
            // Check for goal or save
            if (this.y <= 100) {
                if (this.x > 300 && this.x < 500) {
                    goals++;
                    document.getElementById('goals').textContent = goals;
                }
                this.reset();
            }
            
            // Check for collision with goalkeeper
            if (this.checkGoalkeeperCollision()) {
                saves++;
                document.getElementById('saves').textContent = saves;
                this.reset();
            }
        }
    },
    shoot(targetX, targetY) {
        if (!this.active) {
            this.active = true;
            const dx = targetX - this.x;
            const dy = targetY - this.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            this.direction.x = dx / distance;
            this.direction.y = dy / distance;
        }
    },
    checkGoalkeeperCollision() {
        return this.active &&
               this.x > goalkeeper.x - goalkeeper.width / 2 &&
               this.x < goalkeeper.x + goalkeeper.width / 2 &&
               this.y > goalkeeper.y - goalkeeper.height / 2 &&
               this.y < goalkeeper.y + goalkeeper.height / 2;
    },
    reset() {
        this.active = false;
        this.x = 400;
        this.y = 500;
        this.direction = { x: 0, y: 0 };
    }
};

// Game functions
function init() {
    canvas = document.getElementById('game-canvas');
    ctx = canvas.getContext('2d');
    goals = 0;
    saves = 0;
    document.getElementById('goals').textContent = goals;
    document.getElementById('saves').textContent = saves;
    
    // Event listeners
    canvas.addEventListener('click', handleClick);
    document.addEventListener('keydown', handleKeydown);
}

function handleClick(event) {
    if (gameState === 'playing' && !ball.active) {
        const rect = canvas.getBoundingClientRect();
        const x = event.clientX - rect.left;
        const y = event.clientY - rect.top;
        ball.shoot(x, y);
    }
}

function handleKeydown(event) {
    if (gameState === 'playing') {
        if (event.key === 'ArrowLeft') {
            goalkeeper.dive('left');
        } else if (event.key === 'ArrowRight') {
            goalkeeper.dive('right');
        }
    }
}

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw goal
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(300, 50, 200, 10);
    ctx.fillRect(290, 50, 10, 100);
    ctx.fillRect(500, 50, 10, 100);
    
    goalkeeper.draw();
    ball.draw();
    ball.update();
}

function startGame() {
    gameState = 'playing';
    document.getElementById('start-screen').style.display = 'none';
    document.getElementById('game-over-screen').style.display = 'none';
    init();
    gameLoop();
}

function gameLoop() {
    if (gameState === 'playing') {
        update();
        requestAnimationFrame(gameLoop);
    }
}

function resetGame() {
    goals = 0;
    saves = 0;
    ball.reset();
    goalkeeper.resetDive();
    startGame();
}